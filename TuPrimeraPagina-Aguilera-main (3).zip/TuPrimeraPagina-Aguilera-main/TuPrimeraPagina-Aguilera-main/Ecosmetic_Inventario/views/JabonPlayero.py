from django.views.generic import ListView  # Importamos ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.detail import DetailView
from Ecosmetic_Inventario.models import JabonPlayero


class JabonPlayeroListView(ListView):
    """
    Vista para listar todos los cursos.
    """
    model = JabonPlayero
    template_name = 'Ecosmetic_Inventario/JabonPlayero/JabonPlayero_list.html'
    paginate_by = 10 
    ordering = ['-nombre',] 


class JabonPlayeroDetailView(DetailView):
    """
    Vista para mostrar los detalles de un curso específico.
    """
    model = JabonPlayero
    template_name = 'Ecosmetic_Inventario/JabonPlayero/JabonPlayero_detail.html'


class JabonPlayeroCreateView(CreateView):
    """
    Vista para crear un nuevo curso.
    """
    model = JabonPlayero
    fields = ['nombre', 'precio']
    template_name = 'Ecosmetic/JabonPlayero/JabonPlayero_form.html'
    success_url = '/Ecosmetic_Inventario/JabonPlayero/'  

class JabonPlayeroUpdateView(UpdateView):
    """
    Vista para editar un curso existente.
    """
    model = JabonPlayero
    fields = ['nombre', 'precio']
    template_name = 'Ecosmetic_Inventario/JabonPlayero/JabonPlayero_form.html'
    success_url = '/Ecosmetic_Inventario/JabonPlayero/'  

class JabonPlayeroDeleteView(DeleteView):
    """Vista para eliminar un curso existente.
    """ 
    model = JabonPlayero
    template_name = 'Ecosmetic_Inventario/JabonPlayero/JabonPlayero_confirm_delete.html'
    success_url = '/Ecosmetic_Inventario/JabonPlayero/' 