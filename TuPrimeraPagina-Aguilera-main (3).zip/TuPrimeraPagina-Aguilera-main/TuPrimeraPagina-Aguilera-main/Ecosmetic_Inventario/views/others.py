from django.shortcuts import render, redirect
from ..models import JabonFrutal, JabonFloral, JabonPlayero
from django.contrib import messages
from ..forms import JabonFrutalForm, JabonFloralForm, JabonPlayeroForm, BusquedaForm
from django.http import HttpResponse


def inicio(request):
    # Calculamos estadísticas para el dashboard
    total_jabones_frutales = JabonFrutal.objects.count()
    total_jabones_florales = JabonFloral.objects.count()
    total_jabones_playeros = JabonPlayero.objects.count()
    total_productos = total_jabones_frutales + total_jabones_florales + total_jabones_playeros
    
    context = {
        'total_productos': total_productos,
        'total_jabones_frutales': total_jabones_frutales,
        'total_jabones_florales': total_jabones_florales,
        'total_jabones_playeros': total_jabones_playeros,
    }
    return render(request, "Ecosmetic_Inventario/index.html", context)

def listar_jabones_frutales(request):
    jabones = JabonFrutal.objects.all()
    return render(request, "Ecosmetic_Inventario/productos.html", {'jabones': jabones, 'tipo': 'frutales'})

def listar_jabones_florales(request):
    jabones = JabonFloral.objects.all()
    return render(request, "Ecosmetic_Inventario/productos.html", {'jabones': jabones, 'tipo': 'florales'})

def listar_jabones_playeros(request):
    jabones = JabonPlayero.objects.all()
    return render(request, "Ecosmetic_Inventario/productos.html", {'jabones': jabones, 'tipo': 'playeros'})


def agregar_jabon_frutal(request):
    if request.method == "POST":
        form = JabonFrutalForm(request.POST)
        if form.is_valid():
            info = form.cleaned_data
            jabon = JabonFrutal(
                nombre=info["nombre"],
                precio=info["precio"],
                cantidad=info["cantidad"]  # CORREGIDO: era ["cantidad"] en lugar de info["cantidad"]
            )
            jabon.save()
            messages.success(request, 'Jabón frutal agregado exitosamente')
            return redirect('inicio')  # CORREGIDO: usar redirect en lugar de render
    else:
        form = JabonFrutalForm()
    
    return render(request, "Ecosmetic_Inventario/formulario/jabon_frutal_formulario.html", {"form": form})

def agregar_jabon_floral(request):
    if request.method == "POST":
        form = JabonFloralForm(request.POST)
        if form.is_valid():
            info = form.cleaned_data
            jabon = JabonFloral(
                nombre=info["nombre"],
                precio=info["precio"],
                cantidad=info["cantidad"]  # CORREGIDO: era ["cantidad"] en lugar de info["cantidad"]
            )
            jabon.save()
            messages.success(request, 'Jabón floral agregado exitosamente')
            return redirect('inicio')  # CORREGIDO: usar redirect en lugar de render
    else:
        form = JabonFloralForm()
    
    return render(request, "Ecosmetic_Inventario/formulario/jabon_floral_formulario.html", {"form": form})

def agregar_jabon_playero(request):
    if request.method == "POST":
        form = JabonPlayeroForm(request.POST)
        if form.is_valid():
            info = form.cleaned_data
            jabon = JabonPlayero(
                nombre=info["nombre"],
                precio=info["precio"],
                cantidad=info["cantidad"]  # CORREGIDO: era ["cantidad"] en lugar de info["cantidad"]
            )
            jabon.save()
            messages.success(request, 'Jabón playero agregado exitosamente')
            return redirect('inicio')  # CORREGIDO: usar redirect en lugar de render
    else:
        form = JabonPlayeroForm()
    
    return render(request, "Ecosmetic_Inventario/formulario/jabon_playero_formulario.html", {"form": form})


def busqueda_jabon(request):
    form = BusquedaForm()
    return render(request, "Ecosmetic_Inventario/formulario/busquedaCamada.html", {"form": form})

def buscar_jabon(request):
    if request.GET.get("id"):
        jabon_id = request.GET["id"]
        
        # Buscamos en los tres tipos de jabones
        try:
            frutal = JabonFrutal.objects.get(id=jabon_id)
            tipo = "frutal"
            jabon = frutal
        except JabonFrutal.DoesNotExist:
            frutal = None
        
        try:
            floral = JabonFloral.objects.get(id=jabon_id)
            tipo = "floral"
            jabon = floral
        except JabonFloral.DoesNotExist:
            floral = None
        
        try:
            playero = JabonPlayero.objects.get(id=jabon_id)
            tipo = "playero"
            jabon = playero
        except JabonPlayero.DoesNotExist:
            playero = None
        
        # Si se encuentra al menos uno
        if frutal or floral or playero:
            return render(request, "Ecosmetic_Inventario/formulario/resultadosBusqueda.html", {
                "jabon_frutal": frutal,
                "jabon_floral": floral,
                "jabon_playero": playero,
                "id": jabon_id
            })
        else:
            messages.error(request, "No se encontró ningún jabón con ese ID.")
            return redirect('busqueda_jabon')
    else:
        messages.error(request, "No enviaste ningún ID válido.")
        return redirect('busqueda_jabon')

def informacion_acceso(request):
    """Vista que muestra información sobre cómo acceder al admin"""
    return render(request, "Ecosmetic_Inventario/info_acceso.html")

