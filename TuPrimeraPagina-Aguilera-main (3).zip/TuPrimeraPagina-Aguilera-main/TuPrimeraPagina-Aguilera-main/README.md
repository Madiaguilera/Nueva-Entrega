# Python y Django

## Curso

Comisión 

Profesor: Alan Exequiel Prestia

LinkedIn: 

## Alumno

Nombre:

LinkedIn: