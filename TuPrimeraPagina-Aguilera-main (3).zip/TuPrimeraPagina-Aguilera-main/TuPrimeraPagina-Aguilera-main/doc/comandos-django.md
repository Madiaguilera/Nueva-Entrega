# Django

## Creación de un proyecto

Clonar un repositorio

Crear entorno virtual

Instalar dependencias

Crear un proyecto:

    django-admin startproject config .

Ejecutar el servidor:

    python manage.py runserver

Cambiar el idioma en config/settings.py

    LANGUAGE_CODE = 'es'